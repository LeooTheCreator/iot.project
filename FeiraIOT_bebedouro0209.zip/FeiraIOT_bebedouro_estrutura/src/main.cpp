#include <Arduino.h>
#include "web/webpage.h"

void setup()
{
    // Inicia o Monitor Serial
    Serial.begin(115200);

    // Inicia o Wi-Fi e o servidor
    WebPage.begin();
}

void loop()
{
    // Mantém o servidor funcionando
    WebPage.handleClient();
}