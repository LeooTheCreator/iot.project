#include "webpage.h"

// ======================================================
// PÁGINA HTML
// ======================================================

const char paginaHTML[] PROGMEM = R"rawliteral(

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>FeiraIOT</title>
</head>

<body>

    <h1>Bebedouro Inteligente</h1>

    <p>ESP8266 conectado!</p>

</body>

</html>

)rawliteral";


// ======================================================
// OBJETO DA PÁGINA
// ======================================================

WebPageClass WebPage;


// ======================================================
// CONSTRUTOR
// ======================================================

WebPageClass::WebPageClass()
    : server(80)
{
}


// ======================================================
// INICIA WI-FI E SERVIDOR
// ======================================================

void WebPageClass::begin()
{
    // Cria o ponto de acesso Wi-Fi
    WiFi.mode(WIFI_AP);
    WiFi.softAP(SSID, PASSWORD);

    Serial.println();
    Serial.println("================================");
    Serial.println("        FEIRAIOT - WIFI");
    Serial.println("================================");

    Serial.print("Rede: ");
    Serial.println(SSID);

    Serial.print("Senha: ");
    Serial.println(PASSWORD);

    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());


    // ==================================================
    // NOME .LOCAL
    // ==================================================

    // Cria o endereço:
    //
    // http://FeiraIOT.local
    //
    if (MDNS.begin("FeiraIOT"))
    {
        Serial.println("mDNS iniciado!");
        Serial.println("Acesse: http://FeiraIOT.local");
    }
    else
    {
        Serial.println("Erro ao iniciar mDNS!");
    }


    // ==================================================
    // ROTA PRINCIPAL
    // ==================================================

    server.on("/", [this]()
    {
        server.send_P(
            200,
            "text/html",
            paginaHTML
        );
    });


    // Inicia o servidor HTTP
    server.begin();

    Serial.println("Servidor HTTP iniciado!");
}


// ======================================================
// ATUALIZA SERVIDOR E MDNS
// ======================================================

void WebPageClass::handleClient()
{
    // Verifica requisições da página
    server.handleClient();

    // Mantém o mDNS funcionando
    MDNS.update();
}