#ifndef WEBPAGE_H
#define WEBPAGE_H

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>

class WebPageClass
{
private:
    ESP8266WebServer server;

    const char* SSID = "FeiraIOT";
    const char* PASSWORD = "12345678";

public:
    WebPageClass();

    void begin();
    void handleClient();
};

extern WebPageClass WebPage;

#endif