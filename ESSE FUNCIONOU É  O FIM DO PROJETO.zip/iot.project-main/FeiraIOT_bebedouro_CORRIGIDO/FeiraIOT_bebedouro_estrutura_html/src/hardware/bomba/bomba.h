#ifndef BOMBA_H
#define BOMBA_H

#include <Arduino.h>

class Bomba {
private:
    uint8_t pinoRele;
    bool ligada;

public:
    Bomba(uint8_t pino);

    void iniciar();
    void ligar();
    void desligar();

    bool estaLigada();
};

#endif