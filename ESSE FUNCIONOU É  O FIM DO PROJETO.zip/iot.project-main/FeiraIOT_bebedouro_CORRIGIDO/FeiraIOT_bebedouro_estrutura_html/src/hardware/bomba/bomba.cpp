#include "bomba.h"

Bomba::Bomba(uint8_t pino) {
    pinoRele = pino;
    ligada = false;
}

void Bomba::iniciar() {
    pinMode(pinoRele, OUTPUT);

    // Este módulo de relés trabalha com lógica ativa em LOW.
    // HIGH = relé desligado
    // LOW  = relé ligado
    digitalWrite(pinoRele, HIGH);

    ligada = false;
}

void Bomba::ligar() {
    digitalWrite(pinoRele, LOW);
    ligada = true;
}

void Bomba::desligar() {
    digitalWrite(pinoRele, HIGH);
    ligada = false;
}

bool Bomba::estaLigada() {
    return ligada;
}