#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

#include "hardware/bomba/bomba.h"
#include "web/webpage.h"


// =====================================================
// WI-FI
// =====================================================

const char* SSID = "Bebedouro-ESP";
const char* SENHA = "12345678";

ESP8266WebServer servidor(80);


// =====================================================
// BOMBA / RELÉ
// =====================================================

// D6 do ESP8266 vai para IN1 do módulo de relés.
const uint8_t PINO_RELE_BOMBA = D6;

Bomba bomba(PINO_RELE_BOMBA);


// =====================================================
// CONFIGURAÇÃO DA DOSAGEM
// =====================================================

// Valor inicial.
// DEPOIS da medição da vazão real, alteramos somente este número.
const float VAZAO_ML_POR_MINUTO = 1750.0;

// Limites da quantidade que pode ser solicitada.
const long ML_MINIMO = 1;
const long ML_MAXIMO = 200;


// =====================================================
// CONTROLE DA DOSAGEM
// =====================================================

bool bombeandoPorVolume = false;

unsigned long inicioBombeamento = 0;
unsigned long duracaoBombeamento = 0;


// =====================================================
// INICIAR BOMBEAMENTO
// =====================================================

void iniciarBombeamento(long ml) {

    // Não inicia uma nova dosagem
    // se a bomba já estiver funcionando.
    if (bombeandoPorVolume) {
        return;
    }

    // Converte a quantidade desejada em tempo.

    // Exemplo:
    //
    // 100 mL
    // 1750 mL/min
    //
    // tempo = 100 / 1750 minutos
    //
    // multiplicamos por 60000 para obter milissegundos.

    duracaoBombeamento =
        (unsigned long)(
            (ml * 60000.0) /
            VAZAO_ML_POR_MINUTO
        );

    inicioBombeamento = millis();

    bombeandoPorVolume = true;

    bomba.ligar();

    Serial.print("Bomba ligada para ");
    Serial.print(ml);
    Serial.println(" mL.");

    Serial.print("Duracao: ");
    Serial.print(duracaoBombeamento);
    Serial.println(" ms.");
}


// =====================================================
// PARAR BOMBA
// =====================================================

void pararBomba() {

    bomba.desligar();

    bombeandoPorVolume = false;

    inicioBombeamento = 0;

    duracaoBombeamento = 0;

    Serial.println("Bomba desligada.");
}


// =====================================================
// PÁGINA PRINCIPAL
// =====================================================

void paginaInicialHandler() {

    servidor.send(
        200,
        "text/html",
        paginaInicial()
    );
}


// =====================================================
// SOLICITAR ÁGUA
// =====================================================

void puxarAgua() {

    if (!servidor.hasArg("ml")) {

        servidor.send(
            400,
            "text/plain",
            "Quantidade de agua nao informada."
        );

        return;
    }


    long ml = servidor.arg("ml").toInt();


    if (ml < ML_MINIMO || ml > ML_MAXIMO) {

        servidor.send(
            400,
            "text/plain",
            "Quantidade deve estar entre 1 e 200 mL."
        );

        return;
    }


    if (bombeandoPorVolume) {

        servidor.send(
            409,
            "text/plain",
            "A bomba ja esta funcionando."
        );

        return;
    }


    iniciarBombeamento(ml);


    servidor.send(
        200,
        "text/plain",
        "Bombeamento iniciado."
    );
}


// =====================================================
// PARAR PELO SITE
// =====================================================

void pararBombaWeb() {

    pararBomba();

    servidor.send(
        200,
        "text/plain",
        "Bomba parada."
    );
}


// =====================================================
// INFORMAR ESTADO DA BOMBA
// =====================================================

void estadoBomba() {

    if (bomba.estaLigada()) {

        servidor.send(
            200,
            "text/plain",
            "1"
        );

    } else {

        servidor.send(
            200,
            "text/plain",
            "0"
        );
    }
}


// =====================================================
// SETUP
// =====================================================

void setup() {

    Serial.begin(115200);

    delay(500);

    Serial.println();
    Serial.println("==============================");
    Serial.println("      BEBEDOURO IoT");
    Serial.println("==============================");


    // Inicializa o relé.
    //
    // O método iniciar() coloca o relé
    // em estado DESLIGADO.
    bomba.iniciar();


    // =================================================
    // CRIA A REDE WI-FI DO ESP8266
    // =================================================

    WiFi.mode(WIFI_AP);

    WiFi.softAP(
        SSID,
        SENHA
    );


    Serial.println();
    Serial.println("Wi-Fi iniciado.");

    Serial.print("Nome da rede: ");
    Serial.println(SSID);

    Serial.print("IP do bebedouro: ");
    Serial.println(WiFi.softAPIP());


    // =================================================
    // ROTAS DO SITE
    // =================================================

    servidor.on(
        "/",
        HTTP_GET,
        paginaInicialHandler
    );


    servidor.on(
        "/bomba/puxar",
        HTTP_GET,
        puxarAgua
    );


    servidor.on(
        "/bomba/parar",
        HTTP_GET,
        pararBombaWeb
    );


    servidor.on(
        "/estado",
        HTTP_GET,
        estadoBomba
    );


    servidor.begin();

    Serial.println("Servidor HTTP iniciado.");
}


// =====================================================
// LOOP
// =====================================================

void loop() {

    // Verifica se chegou alguma solicitação
    // do navegador.
    servidor.handleClient();


    // =================================================
    // VERIFICA SE A DOSAGEM TERMINOU
    // =================================================

    if (bombeandoPorVolume) {

        unsigned long tempoPassado =
            millis() - inicioBombeamento;


        if (tempoPassado >= duracaoBombeamento) {

            pararBomba();

            Serial.println(
                "Dosagem finalizada automaticamente."
            );
        }
    }
}