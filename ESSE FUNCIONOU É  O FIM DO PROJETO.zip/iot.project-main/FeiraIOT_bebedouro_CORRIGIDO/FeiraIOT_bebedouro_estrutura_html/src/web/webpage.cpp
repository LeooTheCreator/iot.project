#include "webpage.h"

String paginaInicial() {

    return R"rawliteral(

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>Bebedouro IoT</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 20px;
            background: #111827;
            color: white;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 500px;
            margin: auto;
        }

        .card {
            background: #1f2937;
            padding: 25px;
            border-radius: 15px;
        }

        h1 {
            margin-top: 0;
        }

        .estado {
            padding: 10px;
            border-radius: 8px;
            background: #374151;
            margin-bottom: 20px;
            text-align: center;
        }

        input {
            width: 100%;
            padding: 12px;
            font-size: 18px;
            border-radius: 8px;
            border: none;
            margin: 10px 0 15px;
        }

        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 8px;
        }

        .agua {
            background: #2563eb;
            color: white;
        }

        .parar {
            background: #dc2626;
            color: white;
        }

        .mensagem {
            margin-top: 15px;
            text-align: center;
        }

    </style>

</head>

<body>

<div class="container">

    <div class="card">

        <h1>Bebedouro IoT</h1>

        <div class="estado">
            Estado:
            <strong id="estado">Bomba desligada</strong>
        </div>

        <label for="ml">
            Quantidade de água (mL)
        </label>

        <input
            id="ml"
            type="number"
            min="1"
            max="200"
            value="100">

        <button
            class="agua"
            onclick="puxarAgua()">

            Liberar água

        </button>

        <button
            class="parar"
            onclick="pararBomba()">

            PARAR BOMBA

        </button>

        <div
            class="mensagem"
            id="mensagem">
        </div>

    </div>

</div>

<script>

function puxarAgua() {

    let quantidade =
        Number(document.getElementById("ml").value);

    if (quantidade < 1 || quantidade > 200) {

        document.getElementById("mensagem").innerText =
            "Escolha uma quantidade entre 1 e 200 mL.";

        return;
    }

    fetch("/bomba/puxar?ml=" + quantidade)

        .then(response => response.text())

        .then(texto => {

            document.getElementById("mensagem").innerText =
                texto;

            atualizarEstado();

        })

        .catch(() => {

            document.getElementById("mensagem").innerText =
                "Erro ao comunicar com o ESP8266.";

        });
}


function pararBomba() {

    fetch("/bomba/parar")

        .then(response => response.text())

        .then(texto => {

            document.getElementById("mensagem").innerText =
                texto;

            atualizarEstado();

        });

}


function atualizarEstado() {

    fetch("/estado")

        .then(response => response.text())

        .then(texto => {

            if (texto == "1") {

                document.getElementById("estado").innerText =
                    "Bomba ligada";

            } else {

                document.getElementById("estado").innerText =
                    "Bomba desligada";

            }

        });
}


setInterval(atualizarEstado, 500);

atualizarEstado();

</script>

</body>

</html>

)rawliteral";
}