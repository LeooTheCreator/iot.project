# Bebedouro IoT

Projeto ESP8266 + relé + bomba 12 V.

## Ligações
- D6 -> IN1
- GND -> GND
- VU -> VCC
- IN2/IN3/IN4 não usados
- +12 V -> COM do K1
- NO do K1 -> positivo da bomba
- negativo da bomba -> negativo da fonte
- NC não usado

O código considera relé ativo em LOW:
LOW = ligado
HIGH = desligado

Primeiro teste: conecte ao Wi-Fi Bebedouro-ESP, senha 12345678, abra 192.168.4.1 e pressione TESTAR RELÉ.

Vazão inicial: 1750 mL/min. Calibrar depois da medição real.

Não conecte 12 V ao ESP8266. A parte de rede elétrica da fonte deve ser feita por adulto/profissional habilitado.
