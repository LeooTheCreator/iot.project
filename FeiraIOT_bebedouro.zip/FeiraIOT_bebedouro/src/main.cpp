#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

const char* SSID = "Bebedouro-ESP";
const char* SENHA = "12345678";

ESP8266WebServer servidor(80);

const uint8_t PINO_RELE = D6;
const uint8_t RELE_LIGADO = LOW;
const uint8_t RELE_DESLIGADO = HIGH;

const float VAZAO_ML_POR_MINUTO = 1750.0;
const long ML_MINIMO = 1;
const long ML_MAXIMO = 200;

bool bombaLigada = false;
unsigned long inicioBomba = 0;
unsigned long tempoBomba = 0;

void ligarBomba() {
    digitalWrite(PINO_RELE, RELE_LIGADO);
    bombaLigada = true;
    Serial.println("BOMBA: LIGADA");
    Serial.print("D6: ");
    Serial.println(digitalRead(PINO_RELE) == LOW ? "LOW" : "HIGH");
}

void desligarBomba() {
    digitalWrite(PINO_RELE, RELE_DESLIGADO);
    bombaLigada = false;
    Serial.println("BOMBA: DESLIGADA");
    Serial.print("D6: ");
    Serial.println(digitalRead(PINO_RELE) == LOW ? "LOW" : "HIGH");
}

void iniciarDosagem(long ml) {
    if (bombaLigada) {
        servidor.send(409, "text/plain", "A bomba ja esta ligada.");
        return;
    }

    tempoBomba = (unsigned long)((ml * 60000.0) / VAZAO_ML_POR_MINUTO);
    inicioBomba = millis();

    Serial.println("------ NOVA DOSAGEM ------");
    Serial.print("Quantidade: ");
    Serial.print(ml);
    Serial.println(" mL");
    Serial.print("Tempo: ");
    Serial.print(tempoBomba);
    Serial.println(" ms");

    ligarBomba();
    servidor.send(200, "text/plain", "Bomba ligada. Dosagem iniciada.");
}

void paginaInicial() {
    String pagina = R"rawliteral(
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bebedouro IoT</title>
<style>
body{font-family:Arial;background:#111827;color:white;margin:0;padding:20px}
.container{max-width:500px;margin:auto}
.card{background:#1f2937;padding:25px;border-radius:15px}
.estado{padding:15px;margin:20px 0;background:#374151;border-radius:8px;text-align:center}
input{width:100%;padding:12px;font-size:18px;box-sizing:border-box;margin:10px 0 15px}
button{width:100%;padding:15px;margin-top:10px;border:0;border-radius:8px;font-size:18px}
.agua{background:#2563eb;color:white}.parar{background:#dc2626;color:white}.teste{background:#16a34a;color:white}
#mensagem{margin-top:20px;text-align:center}
</style>
</head>
<body>
<div class="container"><div class="card">
<h1>Bebedouro IoT</h1>
<div class="estado">Estado: <strong id="estado">Bomba desligada</strong></div>
<label>Quantidade de água (mL)</label>
<input id="ml" type="number" min="1" max="200" value="100">
<button class="agua" onclick="liberarAgua()">LIBERAR ÁGUA</button>
<button class="parar" onclick="pararBomba()">PARAR BOMBA</button>
<hr>
<button class="teste" onclick="testeRele()">TESTAR RELÉ</button>
<div id="mensagem"></div>
</div></div>
<script>
function liberarAgua(){
 let ml=Number(document.getElementById("ml").value);
 if(ml<1||ml>200){document.getElementById("mensagem").innerText="Digite um valor entre 1 e 200 mL.";return;}
 fetch("/bomba/puxar?ml="+ml).then(r=>r.text()).then(t=>{document.getElementById("mensagem").innerText=t;atualizarEstado();}).catch(()=>{document.getElementById("mensagem").innerText="Erro de comunicação.";});
}
function pararBomba(){fetch("/bomba/parar").then(r=>r.text()).then(t=>{document.getElementById("mensagem").innerText=t;atualizarEstado();});}
function testeRele(){fetch("/teste").then(r=>r.text()).then(t=>{document.getElementById("mensagem").innerText=t;atualizarEstado();});}
function atualizarEstado(){fetch("/estado").then(r=>r.text()).then(e=>{document.getElementById("estado").innerText=e=="1"?"Bomba ligada":"Bomba desligada";});}
setInterval(atualizarEstado,1000); atualizarEstado();
</script>
</body>
</html>
)rawliteral";
    servidor.send(200, "text/html", pagina);
}

void setup() {
    Serial.begin(115200);
    delay(1000);

    pinMode(PINO_RELE, OUTPUT);
    digitalWrite(PINO_RELE, RELE_DESLIGADO);
    bombaLigada = false;

    Serial.println("BEBEDOURO IoT");
    Serial.println("D6 / GPIO12 configurado.");
    Serial.print("Estado inicial D6: ");
    Serial.println(digitalRead(PINO_RELE) == LOW ? "LOW" : "HIGH");

    WiFi.mode(WIFI_AP);
    WiFi.softAP(SSID, SENHA);

    Serial.print("SSID: ");
    Serial.println(SSID);
    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());

    servidor.on("/", HTTP_GET, [](){ paginaInicial(); });

    servidor.on("/bomba/puxar", HTTP_GET, [](){
        if(!servidor.hasArg("ml")){
            servidor.send(400,"text/plain","Quantidade nao informada.");
            return;
        }
        long ml=servidor.arg("ml").toInt();
        if(ml<ML_MINIMO || ml>ML_MAXIMO){
            servidor.send(400,"text/plain","Quantidade invalida.");
            return;
        }
        iniciarDosagem(ml);
    });

    servidor.on("/bomba/parar", HTTP_GET, [](){
        desligarBomba();
        servidor.send(200,"text/plain","Bomba parada.");
    });

    servidor.on("/estado", HTTP_GET, [](){
        servidor.send(200,"text/plain",bombaLigada?"1":"0");
    });

    servidor.on("/teste", HTTP_GET, [](){
        Serial.println("TESTE MANUAL DO RELE");
        ligarBomba();
        delay(3000);
        desligarBomba();
        servidor.send(200,"text/plain","Teste concluido: rele ficou ligado por 3 segundos.");
    });

    servidor.begin();
    Serial.println("Servidor HTTP iniciado.");
}

void loop() {
    servidor.handleClient();

    if(bombaLigada && millis()-inicioBomba>=tempoBomba){
        desligarBomba();
        Serial.println("Dosagem finalizada automaticamente.");
    }
}
