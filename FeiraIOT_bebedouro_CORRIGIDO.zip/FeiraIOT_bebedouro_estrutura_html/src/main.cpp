#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>

#include "hardware/bomba/bomba.h"
#include "web/webpage.h"

ESP8266WebServer servidor(80);

// Relé 1 da placa de 4 relés.
// IN1 da placa recebe o sinal do D6 do ESP8266.
const uint8_t PINO_RELE = D6;
Bomba bomba(PINO_RELE);

// Vazão inicial estimada da bomba.
// Depois da calibração, substitua pelo valor medido.
const float VAZAO_ML_POR_MINUTO = 1750.0;

const unsigned long ML_MINIMO = 1;
const unsigned long ML_MAXIMO = 200;

unsigned long quantidadeSolicitada = 0;
unsigned long inicioBombeamento = 0;
unsigned long duracaoBombeamento = 0;
bool bombeandoPorVolume = false;

void pararBomba() {
    bomba.desligar();
    bombeandoPorVolume = false;
    duracaoBombeamento = 0;
}

bool iniciarBombeamento(unsigned long ml) {
    // Não inicia outra dosagem enquanto uma já estiver acontecendo.
    if (bombeandoPorVolume) {
        return false;
    }

    // Proteção extra, mesmo que a rota web já valide.
    if (ml < ML_MINIMO || ml > ML_MAXIMO) {
        return false;
    }

    quantidadeSolicitada = ml;

    // Tempo em milissegundos:
    // (mL / (mL/min)) * 60000 ms
    duracaoBombeamento = (unsigned long)((ml * 60000.0) / VAZAO_ML_POR_MINUTO);

    // Garante que uma dosagem muito pequena ainda tenha um tempo mínimo.
    if (duracaoBombeamento < 100) {
        duracaoBombeamento = 100;
    }

    inicioBombeamento = millis();
    bombeandoPorVolume = true;
    bomba.ligar();

    return true;
}

void paginaInicial() {
    servidor.send_P(200, "text/html; charset=UTF-8", paginaHTML);
}

void puxarAgua() {
    if (!servidor.hasArg("ml")) {
        servidor.send(400, "text/plain; charset=UTF-8", "Informe a quantidade de agua.");
        return;
    }

    long ml = servidor.arg("ml").toInt();

    if (ml < (long)ML_MINIMO || ml > (long)ML_MAXIMO) {
        servidor.send(400, "text/plain; charset=UTF-8", "Escolha uma quantidade entre 1 e 200 ml.");
        return;
    }

    if (bombeandoPorVolume) {
        servidor.send(409, "text/plain; charset=UTF-8", "A bomba ja esta funcionando.");
        return;
    }

    if (!iniciarBombeamento((unsigned long)ml)) {
        servidor.send(500, "text/plain; charset=UTF-8", "Nao foi possivel iniciar a bomba.");
        return;
    }

    servidor.send(200, "text/plain; charset=UTF-8", "OK");
}

void pararPelaWeb() {
    pararBomba();
    servidor.send(200, "text/plain; charset=UTF-8", "Bomba parada.");
}

void estado() {
    String json = "{\"bomba\":";
    json += bomba.estaLigada() ? "true" : "false";
    json += ",\"bombeandoPorVolume\":";
    json += bombeandoPorVolume ? "true" : "false";
    json += ",\"ml\":";
    json += String(quantidadeSolicitada);
    json += ",\"tempoRestanteMs\":";

    unsigned long restante = 0;

    if (bombeandoPorVolume) {
        unsigned long decorrido = millis() - inicioBombeamento;

        if (decorrido < duracaoBombeamento) {
            restante = duracaoBombeamento - decorrido;
        }
    }

    json += String(restante);
    json += "}";

    servidor.send(200, "application/json; charset=UTF-8", json);
}

void configurarRotas() {
    servidor.on("/", HTTP_GET, paginaInicial);
    servidor.on("/bomba/puxar", HTTP_GET, puxarAgua);
    servidor.on("/bomba/parar", HTTP_GET, pararPelaWeb);
    servidor.on("/estado", HTTP_GET, estado);
}

void setup() {
    Serial.begin(115200);

    // Garante que a bomba comece desligada.
    bomba.begin();

    WiFi.mode(WIFI_AP);
    WiFi.softAP("FeiraIOT", "12345678");

    if (MDNS.begin("feiraiot")) {
        Serial.println("mDNS ativo: http://feiraiot.local");
    } else {
        Serial.println("Nao foi possivel iniciar o mDNS.");
    }

    configurarRotas();
    servidor.begin();

    Serial.println();
    Serial.println("Bebedouro FeiraIOT iniciado.");
    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());
    Serial.println("Acesse http://192.168.4.1");
}

void loop() {
    servidor.handleClient();
    MDNS.update();

    // Desliga automaticamente quando termina o tempo calculado.
    if (bombeandoPorVolume) {
        unsigned long decorrido = millis() - inicioBombeamento;

        if (decorrido >= duracaoBombeamento) {
            pararBomba();
        }
    }
}
