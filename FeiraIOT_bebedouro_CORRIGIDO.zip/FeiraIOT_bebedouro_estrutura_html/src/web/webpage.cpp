#include "webpage.h"

const char paginaHTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bebedouro FeiraIOT</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f7fb;
            color: #172033;
        }

        .cabecalho {
            background: #18b4f1;
            padding: 22px 16px;
            text-align: center;
        }

        .cabecalho h1 {
            margin: 0;
            font-size: clamp(2rem, 8vw, 4rem);
        }

        .conteudo {
            width: min(700px, 92%);
            margin: 30px auto;
            text-align: center;
        }

        .titulo {
            margin-bottom: 20px;
            font-size: clamp(1.8rem, 7vw, 3rem);
        }

        .valor {
            font-size: clamp(3rem, 15vw, 6rem);
            font-weight: bold;
            margin: 15px 0;
        }

        .valor span {
            font-size: 0.45em;
            font-weight: normal;
        }

        .slider {
            width: 90%;
            margin: 10px auto 30px;
            display: block;
            accent-color: #087fce;
        }

        .botoes {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        button {
            width: 100%;
            border: 0;
            border-radius: 18px;
            padding: 22px;
            font-size: clamp(1.5rem, 7vw, 3rem);
            font-weight: bold;
            cursor: pointer;
        }

        .agua {
            background: #7f9ff8;
            color: #101b45;
        }

        .parar {
            background: #e74c3c;
            color: white;
        }

        button:disabled {
            opacity: 0.55;
            cursor: not-allowed;
        }

        .status {
            margin-top: 25px;
            padding: 15px;
            border-radius: 12px;
            background: white;
            font-size: 1.1rem;
        }

        .aviso {
            margin-top: 15px;
            font-size: 0.95rem;
            color: #596579;
        }
    </style>

    <script>
        var quantidadeAtual = 100;
        var bombeando = false;

        function atualizarQuantidade(valor) {
            quantidadeAtual = parseInt(valor);
            document.getElementById('valor').textContent = quantidadeAtual;
        }

        function puxarAgua() {
            if (bombeando) {
                return;
            }

            var quantidade = quantidadeAtual;

            if (isNaN(quantidade) || quantidade < 1 || quantidade > 200) {
                alert('Escolha uma quantidade entre 1 e 200 ml.');
                return;
            }

            fetch('/bomba/puxar?ml=' + quantidade)
                .then(function(resposta) {
                    return resposta.text().then(function(texto) {
                        return {
                            ok: resposta.ok,
                            status: resposta.status,
                            texto: texto
                        };
                    });
                })
                .then(function(resultado) {
                    if (!resultado.ok) {
                        alert(resultado.texto);
                        return;
                    }

                    atualizarStatus();
                })
                .catch(function() {
                    alert('Nao foi possivel comunicar com o bebedouro.');
                });
        }

        function pararBomba() {
            fetch('/bomba/parar')
                .then(function() {
                    atualizarStatus();
                })
                .catch(function() {
                    alert('Nao foi possivel comunicar com o bebedouro.');
                });
        }

        function atualizarStatus() {
            fetch('/estado')
                .then(function(resposta) {
                    return resposta.json();
                })
                .then(function(estado) {
                    bombeando = estado.bomba;

                    var texto = document.getElementById('status');
                    var botaoAgua = document.getElementById('botaoAgua');

                    if (estado.bomba) {
                        texto.textContent = 'Bomba ligada — liberando ' + estado.ml + ' ml';
                        botaoAgua.disabled = true;
                    } else {
                        texto.textContent = 'Bomba desligada';
                        botaoAgua.disabled = false;
                    }
                })
                .catch(function() {
                    document.getElementById('status').textContent = 'Sem comunicacao com o bebedouro';
                });
        }

        window.onload = function() {
            atualizarQuantidade(100);
            atualizarStatus();
            setInterval(atualizarStatus, 500);
        };
    </script>
</head>

<body>
    <header class="cabecalho">
        <h1>Bebedouro FeiraIOT</h1>
    </header>

    <main class="conteudo">
        <h2 class="titulo">Quantidade</h2>

        <div class="valor">
            <span id="valor">100</span>
            <span>ml</span>
        </div>

        <input
            class="slider"
            type="range"
            min="1"
            max="200"
            value="100"
            oninput="atualizarQuantidade(this.value)"
        >

        <div class="botoes">
            <button id="botaoAgua" class="agua" onclick="puxarAgua()">
                Água
            </button>

            <button class="parar" onclick="pararBomba()">
                Parar bomba
            </button>
        </div>

        <div class="status" id="status">
            Carregando...
        </div>

        <div class="aviso">
            Escolha entre 1 e 200 ml. A quantidade depende da calibração da vazão da bomba.
        </div>
    </main>
</body>
</html>
)rawliteral";
