#include "bomba.h"

Bomba::Bomba(uint8_t pinoRele)
    : pinoRele(pinoRele), ligada(false) {}

void Bomba::begin() {
    pinMode(pinoRele, OUTPUT);

    // O relé começa desligado.
    digitalWrite(pinoRele, RELE_DESLIGADO);
    ligada = false;
}

void Bomba::ligar() {
    digitalWrite(pinoRele, RELE_LIGADO);
    ligada = true;
}

void Bomba::desligar() {
    digitalWrite(pinoRele, RELE_DESLIGADO);
    ligada = false;
}

bool Bomba::estaLigada() {
    return ligada;
}
