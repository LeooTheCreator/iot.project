#ifndef BOMBA_H
#define BOMBA_H

#include <Arduino.h>

class Bomba {
private:
    uint8_t pinoRele;
    bool ligada;

    // A maioria desses módulos de relé de 5 V é acionada em LOW.
    // Se o seu módulo funcionar ao contrário, troque os dois valores.
    static const uint8_t RELE_LIGADO = LOW;
    static const uint8_t RELE_DESLIGADO = HIGH;

public:
    Bomba(uint8_t pinoRele);
    void begin();
    void ligar();
    void desligar();
    bool estaLigada();
};

#endif
