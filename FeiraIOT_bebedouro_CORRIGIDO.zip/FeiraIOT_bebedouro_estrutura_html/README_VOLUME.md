# Bebedouro FeiraIOT

Projeto com ESP8266, bomba DC 12 V e placa de 4 relés.

## Arquitetura

- ESP8266 NodeMCU controla o relé 1.
- D6 do ESP8266 vai para IN1 da placa de relés.
- A placa de relés faz o chaveamento da bomba.
- A bomba é DC 12 V e deve ser alimentada pela fonte de 12 V.
- O botão físico foi removido do projeto.
- O sensor de nível foi removido do projeto.
- D7 não é utilizado.

## Vazão

O valor inicial usado pelo software é 1750 mL/min. Esse valor deve ser calibrado com a bomba e o encanamento reais.

## Interface

A página permite escolher de 1 a 200 mL, iniciar a dosagem e parar a bomba.

## Atenção

Não ligar a bomba diretamente ao ESP8266. O ESP8266 fornece apenas o sinal de controle do relé.
A entrada AC da fonte de alimentação deve ser montada por pessoa qualificada. Este projeto considera a saída DC de baixa tensão da fonte.
