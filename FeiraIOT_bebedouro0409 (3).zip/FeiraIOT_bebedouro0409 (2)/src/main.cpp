#include <Arduino.h>

#include "web/webpage.h"
#include "hardware/bomba/bomba.h"
#include "hardware/botao/botao.h"

void setup()
{
    Serial.begin(115200);

    // Inicia a saída da bomba/relé.
    Bomba.begin();

    // Inicia o botão arcade.
    Botao.begin();

    // Inicia Wi-Fi, mDNS e servidor web.
    WebPage.begin();
}

void loop()
{
    // Mantém o site funcionando.
    WebPage.handleClient();

    // Se o botão arcade for pressionado, alterna a bomba.
    if (Botao.foiPressionado())
    {
        Bomba.alternar();

        if (Bomba.estaLigada())
            Serial.println("BOTAO: BOMBA LIGADA");
        else
            Serial.println("BOTAO: BOMBA DESLIGADA");
    }
}
