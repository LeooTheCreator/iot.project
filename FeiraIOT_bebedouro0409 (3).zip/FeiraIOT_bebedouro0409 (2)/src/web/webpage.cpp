#include "webpage.h"
#include "../hardware/bomba/bomba.h"

// ======================================================
// PÁGINA HTML
// ======================================================

const char paginaHTML[] PROGMEM = R"rawliteral(

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FeiraIOT</title>
</head>

<body>

    <h1>Bebedouro Inteligente</h1>

    <p>ESP8266 conectado!</p>

    <button onclick="bomba('ligar')">Ligar bomba</button>
    <button onclick="bomba('desligar')">Desligar bomba</button>


    <script>
        function bomba(comando)
        {
            fetch('/bomba?comando=' + comando)
                .catch(() => {});
        }
    </script>

</body>

</html>

)rawliteral";


// ======================================================
// OBJETO DA PÁGINA
// ======================================================

WebPageClass WebPage;


// ======================================================
// CONSTRUTOR
// ======================================================

WebPageClass::WebPageClass()
    : server(80)
{
}


// ======================================================
// INICIA WI-FI E SERVIDOR
// ======================================================

void WebPageClass::begin()
{
    WiFi.mode(WIFI_AP);
    WiFi.softAP(SSID, PASSWORD);

    Serial.println();
    Serial.println("================================");
    Serial.println("        FEIRAIOT - WIFI");
    Serial.println("================================");

    Serial.print("Rede: ");
    Serial.println(SSID);

    Serial.print("Senha: ");
    Serial.println(PASSWORD);

    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());

    // Nome local:
    // http://FeiraIOT.local
    if (MDNS.begin("FeiraIOT"))
    {
        Serial.println("mDNS iniciado!");
        Serial.println("Acesse: http://FeiraIOT.local");
    }
    else
    {
        Serial.println("Erro ao iniciar mDNS!");
    }


    // ==================================================
    // PÁGINA PRINCIPAL
    // ==================================================

    server.on("/", [this]()
    {
        server.send_P(200, "text/html", paginaHTML);
    });


    // ==================================================
    // COMANDO DA BOMBA
    // ==================================================

    // Exemplos:
    // /bomba?comando=ligar
    // /bomba?comando=desligar

    server.on("/bomba", [this]()
    {
        if (server.hasArg("comando"))
        {
            String comando = server.arg("comando");

            if (comando == "ligar")
            {
                Bomba.ligar();
                server.send(200, "text/plain", "BOMBA LIGADA");
            }
            else if (comando == "desligar")
            {
                Bomba.desligar();
                server.send(200, "text/plain", "BOMBA DESLIGADA");
            }
            else
            {
                server.send(400, "text/plain", "COMANDO INVALIDO");
            }
        }
        else
        {
            server.send(400, "text/plain", "COMANDO AUSENTE");
        }
    });


    // ==================================================
    // INICIA SERVIDOR
    // ==================================================

    server.begin();

    Serial.println("Servidor HTTP iniciado!");
}


// ======================================================
// ATUALIZA SERVIDOR E MDNS
// ======================================================

void WebPageClass::handleClient()
{
    server.handleClient();
    MDNS.update();
}
