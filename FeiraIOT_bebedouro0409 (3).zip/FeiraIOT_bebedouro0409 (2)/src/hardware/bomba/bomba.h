#ifndef BOMBA_H
#define BOMBA_H

#include <Arduino.h>

class BombaClass
{
private:
    uint8_t pin;
    bool ligada;

public:
    BombaClass(uint8_t pinBomba);

    void begin();
    void ligar();
    void desligar();
    void alternar();

    bool estaLigada();
};

extern BombaClass Bomba;

#endif
