#include "bomba.h"

// Saída da bomba/relé:
// D1 do NodeMCU = GPIO5
BombaClass Bomba(5);

BombaClass::BombaClass(uint8_t pinBomba)
    : pin(pinBomba), ligada(false)
{
}

void BombaClass::begin()
{
    pinMode(pin, OUTPUT);
    desligar();
}

void BombaClass::ligar()
{
    digitalWrite(pin, HIGH);
    ligada = true;
}

void BombaClass::desligar()
{
    digitalWrite(pin, LOW);
    ligada = false;
}

void BombaClass::alternar()
{
    if (ligada)
        desligar();
    else
        ligar();
}

bool BombaClass::estaLigada()
{
    return ligada;
}
