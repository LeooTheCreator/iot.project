#include "botao.h"

// D2 do NodeMCU = GPIO4
// Ligação recomendada: COM do botão -> GND
//                      NO do botão  -> D2/GPIO4
BotaoClass Botao(4);

BotaoClass::BotaoClass(uint8_t pinBotao)
    : pin(pinBotao),
      estadoAnterior(HIGH),
      ultimaMudanca(0)
{
}

void BotaoClass::begin()
{
    // Usa o resistor de pull-up interno do ESP8266.
    pinMode(pin, INPUT_PULLUP);
    estadoAnterior = digitalRead(pin);
}

bool BotaoClass::foiPressionado()
{
    bool estadoAtual = digitalRead(pin);

    if (estadoAtual != estadoAnterior)
    {
        unsigned long agora = millis();

        if (agora - ultimaMudanca >= debounce)
        {
            ultimaMudanca = agora;

            bool pressionado = (estadoAnterior == HIGH && estadoAtual == LOW);
            estadoAnterior = estadoAtual;

            return pressionado;
        }
    }

    return false;
}
