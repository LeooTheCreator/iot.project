#ifndef BOTAO_H
#define BOTAO_H

#include <Arduino.h>

class BotaoClass
{
private:
    uint8_t pin;
    bool estadoAnterior;
    unsigned long ultimaMudanca;
    const unsigned long debounce = 50;

public:
    BotaoClass(uint8_t pinBotao);

    void begin();

    // Retorna true somente quando um novo pressionamento é detectado.
    bool foiPressionado();
};

extern BotaoClass Botao;

#endif
