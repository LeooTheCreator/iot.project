#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>

// ============================================================
// FEIRAIOT - BEBEDOURO COM ESP8266
// Relé de 4 canais: usamos somente IN1.
// IMPORTANTE: nesta versão, LOW liga o relé e HIGH desliga.
// ============================================================

// Wi-Fi criado pelo próprio ESP8266; não precisa de internet.
const char* NOME_REDE = "Bebedouro-ESP";
const char* SENHA_REDE = "12345678";

// IN1 do módulo de relé conectado ao pino D6 do NodeMCU.
const uint8_t PINO_RELE = D6;
const uint8_t RELE_LIGADO = LOW;
const uint8_t RELE_DESLIGADO = HIGH;

// Vazão inicial estimada. Calibre medindo o volume real bombeado.
// 1750 mL/min é apenas um ponto de partida, não uma medição confirmada.
const float VAZAO_ML_POR_MINUTO = 1750.0f;

// Limites apresentados pela página.
const long ML_MINIMO = 1;
const long ML_MAXIMO = 200;

ESP8266WebServer servidor(80);

bool bombaLigada = false;
bool dosagemAtiva = false;
bool testeReleAtivo = false;
unsigned long inicioAcionamento = 0;
unsigned long duracaoAcionamento = 0;
unsigned long volumeSolicitado = 0;

const char PAGINA_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bebedouro Infocod</title>
<style>
* { box-sizing: border-box; }
body { margin: 0; padding-bottom: 24px; font-family: Arial, Helvetica, sans-serif; color: #111; }
.head { background-color: rgb(24, 180, 241); width: 100%; min-height: 90px; display: flex; align-items: center; justify-content: center; padding: 12px; }
.bebedouro { font-size: clamp(2rem, 8vw, 4rem); margin: 0; text-align: center; }
.quantidade { display: flex; justify-content: center; align-items: center; font-size: clamp(2.5rem, 8vw, 5rem); margin: 24px 0; }
.controle { text-align: center; padding: 0 16px; }
input[type=range] { width: 80%; max-width: 700px; -webkit-appearance: none; appearance: none; background: transparent; }
input[type=range]::-webkit-slider-runnable-track { height: 30px; background-color: rgb(0, 140, 255); border-radius: 40px; }
input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; height: 40px; width: 40px; background-color: rgb(12, 37, 182); border-radius: 50%; margin-top: -5px; }
input[type=range]::-moz-range-track { height: 30px; background-color: rgb(0, 140, 255); border-radius: 40px; }
input[type=range]::-moz-range-thumb { height: 40px; width: 40px; background-color: rgb(12, 37, 182); border: 0; border-radius: 50%; }
.valor { display: flex; justify-content: center; align-items: center; gap: 8px; margin: 16px auto 28px; }
input[type=number] { width: 150px; border: none; background: transparent; font-size: clamp(3rem, 10vw, 6rem); text-align: right; }
.ml { font-size: clamp(2.5rem, 8vw, 5rem); margin: 0; }
.botao { width: 80%; min-height: 85px; display: block; margin: 20px auto 0; font-size: clamp(2rem, 7vw, 4rem); border: 0; border-radius: 20px; cursor: pointer; }
.agua { background-color: rgb(127, 159, 248); }
.agua:active { background-color: rgb(5, 5, 156); color: white; transform: translateY(3px); }
.parar { background-color: rgb(64, 226, 113); }
.parar:active { background-color: rgb(17, 102, 43); color: white; transform: translateY(3px); }
.teste { background-color: #e6e6e6; font-size: clamp(1.2rem, 4vw, 2rem); min-height: 55px; }
#status { text-align: center; font-size: 1.1rem; margin: 18px 12px; }
</style>
<script>
function atualizarValor(valor) {
  document.getElementById('textInput').value = valor;
}
function atualizarSlider(valor) {
  var n = parseInt(valor, 10);
  if (isNaN(n)) return;
  n = Math.max(1, Math.min(200, n));
  document.getElementById('textInput').value = n;
  document.getElementById('rangeInput').value = n;
}
function puxarAgua() {
  var quantidade = parseInt(document.getElementById('textInput').value, 10);
  if (isNaN(quantidade) || quantidade < 1 || quantidade > 200) {
    alert('Escolha uma quantidade entre 1 e 200 ml.'); return;
  }
  document.getElementById('status').textContent = 'Enviando comando...';
  fetch('/bomba/puxar?ml=' + quantidade).then(function(r) {
    return r.text().then(function(t) { if (!r.ok) throw new Error(t); return t; });
  }).then(function() {
    document.getElementById('status').textContent = 'Dosando aproximadamente ' + quantidade + ' ml.';
  }).catch(function(e) {
    document.getElementById('status').textContent = e.message || 'Falha na comunicação.';
  });
}
function pararAgua() {
  fetch('/bomba/parar').then(function(r) {
    return r.text().then(function(t) { if (!r.ok) throw new Error(t); return t; });
  }).then(function() {
    document.getElementById('status').textContent = 'Comando de parada enviado.';
  }).catch(function() {
    document.getElementById('status').textContent = 'Falha ao comunicar com o bebedouro.';
  });
}
function testarRele() {
  document.getElementById('status').textContent = 'Testando o relé por 3 segundos...';
  fetch('/teste').then(function(r) {
    return r.text().then(function(t) { if (!r.ok) throw new Error(t); return t; });
  }).then(function() {
    document.getElementById('status').textContent = 'Teste iniciado: o relé deve atuar por cerca de 3 segundos.';
  }).catch(function(e) {
    document.getElementById('status').textContent = e.message || 'Falha ao testar o relé.';
  });
}
</script>
</head>
<body>
<header><div class="head"><p class="bebedouro">Bebedouro Infocod</p></div></header>
<p class="quantidade">Quantidade</p>
<div class="controle">
  <input id="rangeInput" type="range" min="1" max="200" step="1" value="100" oninput="atualizarValor(this.value)">
  <div class="valor">
    <input type="number" id="textInput" min="1" max="200" value="100" oninput="atualizarSlider(this.value)">
    <p class="ml">ml</p>
  </div>
</div>
<button class="botao agua" onclick="puxarAgua()">LIBERAR ÁGUA</button>
<button class="botao parar" onclick="pararAgua()">PARAR BOMBA</button>
<button class="botao teste" onclick="testarRele()">TESTAR RELÉ (3 s)</button>
<p id="status">Conecte-se ao Wi-Fi Bebedouro-ESP para usar o bebedouro.</p>
</body>
</html>
)rawliteral";

void desligarBomba() {
    digitalWrite(PINO_RELE, RELE_DESLIGADO);
    bombaLigada = false;
    dosagemAtiva = false;
    testeReleAtivo = false;
    duracaoAcionamento = 0;
}

void ligarPorTempo(unsigned long duracaoMs, bool ehTeste) {
    digitalWrite(PINO_RELE, RELE_LIGADO);
    bombaLigada = true;
    dosagemAtiva = !ehTeste;
    testeReleAtivo = ehTeste;
    inicioAcionamento = millis();
    duracaoAcionamento = duracaoMs;
}

void paginaInicial() {
    servidor.send_P(200, "text/html; charset=UTF-8", PAGINA_HTML);
}

void puxarAgua() {
    if (!servidor.hasArg("ml")) {
        servidor.send(400, "text/plain; charset=UTF-8", "Informe a quantidade em ml.");
        return;
    }

    // toInt() pode transformar texto inválido em zero; os limites rejeitam isso.
    long ml = servidor.arg("ml").toInt();
    if (ml < ML_MINIMO || ml > ML_MAXIMO) {
        servidor.send(400, "text/plain; charset=UTF-8", "Escolha uma quantidade entre 1 e 200 ml.");
        return;
    }

    if (bombaLigada) {
        servidor.send(409, "text/plain; charset=UTF-8", "A bomba ja esta ligada. Pare ou aguarde antes de iniciar outra acao.");
        return;
    }

    volumeSolicitado = (unsigned long)ml;
    unsigned long tempo = (unsigned long)((ml * 60000.0f) / VAZAO_ML_POR_MINUTO);
    if (tempo < 100) tempo = 100;

    ligarPorTempo(tempo, false);
    Serial.printf("Dosagem iniciada: %ld mL; tempo estimado: %lu ms\n", ml, tempo);
    servidor.send(200, "text/plain; charset=UTF-8", "OK");
}

void pararPelaWeb() {
    desligarBomba();
    Serial.println("Bomba desligada pelo comando web.");
    servidor.send(200, "text/plain; charset=UTF-8", "OK");
}

void testarRele() {
    if (bombaLigada) {
        servidor.send(409, "text/plain; charset=UTF-8", "A bomba/relé ja esta ligado. Pare ou aguarde primeiro.");
        return;
    }

    ligarPorTempo(3000, true);
    Serial.println("Teste do rele iniciado por 3 segundos.");
    servidor.send(200, "text/plain; charset=UTF-8", "Teste do rele iniciado.");
}

void enviarEstado() {
    String json = "{\"bomba\":";
    json += bombaLigada ? "true" : "false";
    json += ",\"dosagemAtiva\":";
    json += dosagemAtiva ? "true" : "false";
    json += ",\"testeReleAtivo\":";
    json += testeReleAtivo ? "true" : "false";
    json += ",\"ml\":";
    json += String(volumeSolicitado);
    json += "}";
    servidor.send(200, "application/json; charset=UTF-8", json);
}

void setup() {
    // Define o estado desligado antes de configurar o pino como saída.
    digitalWrite(PINO_RELE, RELE_DESLIGADO);
    pinMode(PINO_RELE, OUTPUT);

    Serial.begin(115200);
    delay(100);
    desligarBomba();

    WiFi.mode(WIFI_AP);
    bool redeCriada = WiFi.softAP(NOME_REDE, SENHA_REDE);

    Serial.println();
    Serial.println("=== FeiraIOT - Bebedouro ===");
    Serial.printf("Wi-Fi criado: %s\n", redeCriada ? "sim" : "nao");
    Serial.printf("Rede: %s\n", NOME_REDE);
    Serial.printf("Senha: %s\n", SENHA_REDE);
    Serial.print("Pagina: http://");
    Serial.println(WiFi.softAPIP());

    if (MDNS.begin("feiraiot")) {
        Serial.println("Endereco alternativo: http://feiraiot.local");
    }

    servidor.on("/", HTTP_GET, paginaInicial);
    servidor.on("/bomba/puxar", HTTP_GET, puxarAgua);
    servidor.on("/bomba/parar", HTTP_GET, pararPelaWeb);
    servidor.on("/estado", HTTP_GET, enviarEstado);
    servidor.on("/teste", HTTP_GET, testarRele);
    servidor.onNotFound([]() {
        servidor.send(404, "text/plain; charset=UTF-8", "Pagina nao encontrada.");
    });

    servidor.begin();
    Serial.println("Servidor web iniciado.");
}

void loop() {
    servidor.handleClient();
    MDNS.update();

    if (bombaLigada && duracaoAcionamento > 0 &&
        (unsigned long)(millis() - inicioAcionamento) >= duracaoAcionamento) {
        desligarBomba();
        Serial.println("Tempo terminado: rele desligado.");
    }
}
