void setup() {
    // inicialização
}

void loop() {
    // funcionamento do bebedouro
}